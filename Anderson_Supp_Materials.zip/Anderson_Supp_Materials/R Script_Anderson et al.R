
#' **SUPPLEMENTARY MATERIAL - R CODE FOR ANDERSON ET AL.**

# Code for the data analysis and production of figures 
#  utilised in Anderson et al. 

# Written in R script. Originally run on RStudio (R version 3. 6. 3)

# CONTENTS
# PART 1: QUANTIFYING CONNECTIVITY & TARTANGRAPH EDGE NUMBER
# PART 2: CODE FOR FIGURE 3
# PART 3: QUANTIFYING CONNECTIVITY & CONNECTING-EDGE WIDTH
# PART 4: CODE FOR FIGURES 4 AND 5
# PART 5: QUANTIFYING CONNECTIVITY & TRANSECTING-EDGE WIDTH
# PART 6: CODE FOR FIGURE 6

# =================================================================

#' **PART 1 : QUANTIFYING CONNECTIVITY & TARTANGRAPH EDGE NUMBER**

# The following code was used to quantify connectivity of 
#  TartanGraphs using the connectivity matrices produced by the
#   RangeShifter dispersal modelling platform.
# This code also creates a dataset that allows comparisson of 
#  connectivity parameters with three independant variables: 
#   number of "connecting-edges", number of "transecting-edges" and
#    directional persistence.

# ===

# Set directory to examine the relevent Connectivity Matrices (CMs)

#setwd("C:/ ... /Anderson_Supp_Materials/SMS_Outputs1_Edge_Number_Analysis")
setwd("C:/Users/calum/Documents/PhD/TartanSimulation/Anderson_Supp_Materials/SMS_Outputs1_Edge_Number_Analysis")


# Create a list of the 20 CMs for later use in a loop

CMatrix<-list.files(pattern="*_Connect.txt")



# Create charcter strings representing the different values 
#  of independant variables used in the experiment

# Directional Persistence (DP)
dp<-rep(c(2.5,5,7.5,10),5)

# Connecting-edges
ce<-sort(rep(c(3,5,9,17,33),4))

# Transecting-edges
te<-sort(rep(c(0,3,7,15,31),2))



# Create a string representing the natal patch ID numbers used as
#  a field in the CMs

StartPatch<-seq(2,11)


# Create a data frame matching transecting-edges numbers to the
#  corresponding patch IDs of each TartanGraph

T_edges<-data.frame(cbind(StartPatch,te))



# For each of the 20 CMs, the data in loaded into R as data-frames 
#  and the relevent variable treatments of each simulation
#   appended into them as additional fields

for(i in 1:length(CMatrix))
{
  CM<-read.table(CMatrix[i], header=TRUE)  # Create a table of CM "i"
  
  CM<-data.frame(CM)   # Make CM "i" a data frame
  
  CM$CM.No<-paste(i)   # A note of which CM these observations came from
  
  CM$dp<-dp[i]   # Enter directional persistence treatment as new field
  
  CM$ce<-ce[i]   # Enter connecting-edge number as new field
  
  if(i==1){ComCM<-CM}   # CM of the first iteration assigned as the compiled data set
  
  else{ComCM<-rbind(ComCM,CM)} # The data of CMs in subsequent iterations added to the compiled data set
}
head(ComCM)


# Numbers of transecting-edges added to final data as a new field
#  by matching them to corresponding patch IDs

ComCM<-merge(ComCM, T_edges, by="StartPatch")
head(ComCM)


# Delete "no data" entries as these are summary statistics for 
#  each year

ComCM<-ComCM[!(ComCM$StartPatch==-999),] 
ComCM<-ComCM[!(ComCM$EndPatch==-999),]   
head(ComCM)


# Remove first ten years of each replicate as this was the 
#  initialisation period of simulations

ComCM<-ComCM[!(ComCM$Year < 10),]

# DELETING DUPLICATE OBSERVATIONS
# The CMs count the number of successful inter-patch dispersals 
#  each year for each natal patch, meaning that TartanGraphs can
#   experiance two successful dispersals in one year if individuals 
#    from either end of the landscape settle in the other patch.

# However, we only want to know whether at least one successful 
#  dispersal took place each year to quantify connectivity, meaning
#   we have to reduce the dataset to only give us one or zero 
#    observations for each replicate, year and TartanGraph.

# Create data frame matching patch IDs with unique TartanGraph IDs
#  to identify the five landscapes in each CM

TG_letters<-c("A","A","B","B","C","C","D","D","E","E")
TGID<-data.frame(StartPatch=StartPatch, TGID=TG_letters)

# Add TartanGraph IDs as new field to the complied CM data

ComCM<-merge(ComCM, TGID, by="StartPatch")

# Assign a code to each observation based on its CM of origin,
# the replicate and year it was recorded in-silico and the ID
#  of the TartanGraph it pertains to.

ComCM$Code<-paste(ComCM$CM.No, ComCM$Rep, ComCM$Year, ComCM$TGID)
head(ComCM)

# Lastly, when two observations have identical codes, one is deleted

ComCM<-ComCM[!duplicated(ComCM$Code),]




# To quantify connectivity of each TartanGraph as Freq, (the number
#  of years in simulation where at least one individual dispersed 
#   from one patch to the other) the table function was used to 
#    provide counts of the number of observations in the compiled 
#     Con_Mat data for each combination of DP, connecting-edge
#      number and transecting-edge number

Freq_ComCM<-data.frame(table(D_P=ComCM$dp, ConnectingE=ComCM$ce, TransectingE=ComCM$te))

head(Freq_ComCM)

str(Freq_ComCM)

# The final data set indicates connectivity in Freq for 25 different
#  TartanGraphs under four different treatments of DP.
# Freq is a whole number that indicates how many years, out
#  of the 5000 considered, a successful dispersal took place in
#   each TartanGraph under each DP treatment in either direction
#    across the landscape.

#=========================================================

#' **PART 2: CODE TO PRODUCE FIGURE 3**

# Subset observations from the final dataset corresponding to DP treatment of 7.5

Fig3Data<-subset(Freq_ComCM, D_P==7.5)

# Create colours for the barplot

cols<- c(red="#e60047", orange="#E69F00", skyblue="#56B4E9",
         bluegreen="#009E73", yellow="#F0E442")

# Create barplot

barplot(Fig3Data$Freq, names.arg = Fig3Data$TransectingE, 
             xlab= "Number of Transecting-Edges", 
             ylab = "Frequency of Dispersal (Freq)     DP = 7.5", 
             ylim=c(0,5500), col = cols, cex.names=0.8)

# Add legend

legend(21, 5500, legend=c("3","5","9","17","33"), 
       fill=c(cols), title = "Number of Connecting-Edges")

#==========================================================

#' **PART 3: QUANTIFYING CONNECTIVITY & CONNECTING-EDGE WIDTH**

# The following code was used to quantify the effect of 
#  experimentally altering the width of connecting-edges.
# This involved including connecting-edge width as an 
#  independant variable and examining the connectivity of 48
#   TartanGraphs across 16 CMs.

#==============

# Set directory to examine the relevent Connectivity Matrices (CMs)

#setwd("C:/ ... /Anderson_Supp_Materials/SMS_Outputs2_Edge_Number_Analysis")
setwd("C:/Users/calum/Documents/PhD/TartanSimulation/Anderson_Supp_Materials/SMS_Outputs2_Edge_Width_Analysis")


# Create a list of the 16 CMs for later use in a loop

CMatrix<-list.files(pattern="*_Connect.txt")
CMatrix<-CMatrix[1:16]


# Create charcter strings representing the different values
#  of independant variables used in the experiment

# Directional Persistence (DP)
dp<-rep(c(2.5,5,7.5,10),4)

# Connecting-edges
ce<-rep(c(3,3,5,5,9,9,17,17),3)

# Transecting-edges
te<-sort(rep(c(0,3,7,15),4))

# Connecting-edge widths (measured as no. of cells wide)
CeWid<-sort(rep(c(2,4,6),8))


# Create a string representing the natal patch ID numbers used as
#  a field in the CMs

StartPatch<-seq(2,25)


# Create a data frame matching connecting-edges numbers and 
#  diametersto the corresponding patch IDs of each TartanGraph

C_edges<-data.frame(cbind(StartPatch, ce, CeWid))



# For each of the 16 CMs, the data in loaded into R as data-frames 
#  and the relevent variable treatments of each simulation
#   appended into them as additional fields

for(i in 1:length(CMatrix))
{
  CM<-read.table(CMatrix[i], header=TRUE)  # Create a table of CM "i"
  
  CM<-data.frame(CM)   # Make CM "i" a data frame
  
  CM$CM.No<-paste(i)   # A note of which CM these observations came from
  
  CM$dp<-dp[i]   # Enter directional persistence treatment as new field
  
  CM$te<-te[i]   # Enter transecting-edge number as new field
  
  if(i==1){ComCM<-CM}   # CM of the first iteration assigned as the compiled data set
  
  else{ComCM<-rbind(ComCM,CM)} # The data of CMs in subsequent iterations added to the compiled data set
}
head(ComCM)


# Connecting-edge numbers and widths added to final data as a new 
#  field by matching them to corresponding patch IDs
ComCM<-merge(ComCM, C_edges, by="StartPatch")
head(ComCM)


# Delete "no data" entries / summary statistics
ComCM<-ComCM[!(ComCM$StartPatch==-999),] 
ComCM<-ComCM[!(ComCM$EndPatch==-999),]  
head(ComCM)


# Remove first ten years of each replicate 
ComCM<-ComCM[!(ComCM$Year < 10),]



# DELETING DUPLICATE OBSERVATIONS
#  Create data frame matching patch IDs with unique TartanGraph 
#   IDs to identify the 12 landscapes in each CM

TG_letters<-c("A","A","B","B","C","C","D","D","E","E","F","F",
              "G","G","H","H","I","I","J","J","K","K","L","L")
TGID<-data.frame(StartPatch=StartPatch, TGID=TG_letters)


# Add TartanGraph IDs as new field to the complied CM data
ComCM<-merge(ComCM, TGID, by="StartPatch")


# Assign a code to each observation 
ComCM$Code<-paste(ComCM$CM.No, ComCM$Rep, ComCM$Year, ComCM$TGID)
head(ComCM)


# When two observations have identical codes, one is deleted
ComCM<-ComCM[!duplicated(ComCM$Code),]


# Quantify connectivity of each TartanGraph as Freq for each 
#  combination of DP, connecting-edge number, transecting-edge 
#   number and connecting-edge width.

Freq_ComCM<-data.frame(table(D_P=ComCM$dp, ConnectingE=ComCM$ce, TransectingE=ComCM$te, ConnEdWid=ComCM$CeWid))

head(Freq_ComCM)

str(Freq_ComCM)

# The final data set indicates connectivity in Freq for 48 
#  different TartanGraphs under four different treatments of DP.

#====================================================

#' **PART 4: CODE FOR FIGURES 4 AND 5**
#'
#' FIGURE 4

# Subset observations from the final dataset corresponding to DP treatment of 10.0
Fig4Data<-subset(Freq_ComCM, D_P==10.0)


# Create dataframe with the mean Freq values of TaratanGraphs sharing the same number of transecting-edges
Fig4Data<-aggregate(Fig4Data$Freq, by=list(Fig4Data$ConnectingE, 
                                  Fig4Data$ConnEdWid), FUN=mean)
names(Fig4Data)<-c("ConnectingE","ConnEdWid","Freq")


# Create colours for the barplot
cols<- c(orange="#E69F00", skyblue="#56B4E9",
         bluegreen="#009E73", yellow="#F0E442")


# Create barplot
barplot(Fig4Data$Freq, names.arg = Fig4Data$ConnEdWid, 
        xlab= "Width of Connecting-Edges (No. Cells)", 
        ylab = "Frequency of Dispersal (Freq)     DP = 10.0", 
        ylim=c(0,8000), col = cols, cex.names=0.8)


# Add legend
legend(9, 8000, legend=c("3","5","9","17"), 
       fill=c(cols), title = "Number of Connecting-Edges")


#' FIGURE 5

#Create colours for the barplot
cols<- c(orange="#E69F00", skyblue="#56B4E9", bluegreen="#009E73")


# Create dataframe with the mean Freq values of TaratanGraphs sharing the same number of both edges types
Fig5Data<-aggregate(Freq_ComCM$Freq, by=list(Freq_ComCM$ConnEdWid, 
                                       Freq_ComCM$D_P), FUN=mean)
names(Fig5Data)<-c("Width","DP","Freq")


# Remove observations from under DP treatment 2.5
Fig5Data<-Fig5Data[!(Fig5Data$DP=="2.5"),]


barplot(Fig5Data$Freq, names.arg = Fig5Data$DP,
             xlab= "Directional Persistence", 
             ylab = "Mean Frequency of Dispersal (Freq)", 
             ylim=c(0,5000), col = cols)

legend(1, 5000, legend=c("2","4","6"), fill=c(cols), 
       title = "Width of Connecting-Edges (cells)")

#======================================================

#' **PART 5: QUANTIFYING CONNECTIVITY & TRANSECTING-EDGE WIDTH**

# The following code was used to quantify the effect of 
#  experimentally altering the width of transecting-edges.
# This involved including connecting-edge width as an 
#  independant variable and examining the connectivity of 36
#   TartanGraphs across 16 CMs.

#==============

# Set directory to examine the relevent Connectivity Matrices (CMs)

#setwd("C:/ ... /Anderson_Supp_Materials/SMS_Outputs2_Edge_Number_Analysis")
setwd("C:/Users/calum/Documents/PhD/TartanSimulation/Anderson_Supp_Materials/SMS_Outputs2_Edge_Width_Analysis")


# Create a list of the 16 CMs for later use in a loop

CMatrix<-list.files(pattern="*_Connect.txt")
CMatrix<-CMatrix[17:32]


# Create charcter strings representing the different values
#  of independant variables used in the experiment

# Directional Persistence (DP)
dp<-rep(c(2.5,5,7.5,10),4)

# Connecting-edges
ce<-sort(rep(c(3,5,9,17),4))

# Transecting-edges
te<-rep(c(3,3,7,7,15,15),3)

# Transecting-edge widths (measured as no. of cells wide)
TeWid<-sort(rep(c(2,4,6),6))


# Create a string representing the natal patch ID numbers used as
#  a field in the CMs

StartPatch<-seq(2,19)


# Create a data frame matching transecting-edges numbers and 
#  diameters to the corresponding patch IDs of each TartanGraph

T_edges<-data.frame(cbind(StartPatch, te, TeWid))



# For each of the 16 CMs, the data in loaded into R as data-frames 
#  and the relevent variable treatments of each simulation
#   appended into them as additional fields

for(i in 1:length(CMatrix))
{
  CM<-read.table(CMatrix[i], header=TRUE)  # Create a table of CM "i"
  
  CM<-data.frame(CM)   # Make CM "i" a data frame
  
  CM$CM.No<-paste(i)   # A note of which CM these observations came from
  
  CM$dp<-dp[i]   # Enter directional persistence treatment as new field
  
  CM$ce<-ce[i]   # Enter connecting-edge number as new field
  
  if(i==1){ComCM<-CM}   # CM of the first iteration assigned as the compiled data set
  
  else{ComCM<-rbind(ComCM,CM)} # The data of CMs in subsequent iterations added to the compiled data set
}
head(ComCM)


# Transecting-edge numbers and widths added to final data as a new 
#  field by matching them to corresponding patch IDs
ComCM<-merge(ComCM, T_edges, by="StartPatch")
head(ComCM)


# Delete "no data" entries / summary statistics
ComCM<-ComCM[!(ComCM$StartPatch==-999),] 
ComCM<-ComCM[!(ComCM$EndPatch==-999),]   
head(ComCM)


# Remove first ten years of each replicate 
ComCM<-ComCM[!(ComCM$Year < 10),]



# DELETING DUPLICATE OBSERVATIONS
#  Create data frame matching patch IDs with unique TartanGraph 
#   IDs to identify the nine landscapes in each CM

TG_letters<-c("A","A","B","B","C","C","D","D","E","E","F","F",
              "G","G","H","H","I","I")
TGID<-data.frame(StartPatch=StartPatch, TGID=TG_letters)


# Add TartanGraph IDs as new field to the complied CM data
ComCM<-merge(ComCM, TGID, by="StartPatch")


# Assign a code to each observation 
ComCM$Code<-paste(ComCM$CM.No, ComCM$Rep, ComCM$Year, ComCM$TGID)
head(ComCM)


# When two observations have identical codes, one is deleted
ComCM<-ComCM[!duplicated(ComCM$Code),]


# Quantify connectivity of each TartanGraph as Freq for each 
#  combination of DP, connecting-edge number, transecting-edge 
#   number and transecting-edge width.

Freq_ComCM<-data.frame(table(D_P=ComCM$dp, ConnectingE=ComCM$ce, TransectingE=ComCM$te, TrannEdWid=ComCM$TeWid))

head(Freq_ComCM)

str(Freq_ComCM)

# The final data set indicates connectivity in Freq for 36 
#  different TartanGraphs under four different treatments of DP.

#====================================================

#' **PART 6: CODE FOR FIGURE 6**
#'
#' FIGURE 6

# Subset observations from the final dataset corresponding to DP treatment of 10.0
Fig6Data<-subset(Freq_ComCM, D_P==10.0)

# Create colours for the barplot
cols<- c(orange="#E69F00", skyblue="#56B4E9", bluegreen="#009E73")

# Obtain the mean Freq values of TartanGraphs sharing the same numebr of connecting-edges
Fig6Data<-aggregate(Fig6Data$Freq, by=list(Fig6Data$TransectingE, Fig6Data$TrannEdWid), FUN=mean)
names(Fig6Data)<-c("TransectingE","TranEdWid","Freq")

# Create barplot
barplot(Fig6Data$Freq, names.arg = Fig6Data$TranEdWid,
             xlab= "Width of Transecting-Edges (No. Cells)", 
             ylab = "Mean Frequency of Dispersal (Freq)     DP = 10.0", 
             ylim=c(0,5500), col = cols)

legend(6, 5500, legend=c("3","7","15"), 
       fill=c(cols), title = "Number of Transecting-Edges")
